function compTitle (textTitle){
  return "<h1>" + textTitle + "</h1>"
}

function compParagrafo (textParagrafo){
  return "<p>" + textParagrafo + "</p>"
}

function compButton (textButton){
  return "<button>" + textButton + "</button>"
}

function render (){
  
  var pageToRender =  compTitle("BRASIL É HEXA") + compParagrafo("Se o Neymar jogar a gente perde") + compButton("GOL DO BRASIL") + compButton("GOL DE PORTUGAL") + compTitle("O SANGUE PORTUGUES CORRE EM MINHAS VEIAS");
      
  document.getElementById("root").innerHTML = pageToRender;
  
}

render();
