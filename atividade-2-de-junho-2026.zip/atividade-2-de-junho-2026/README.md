# ATIVIDADE 2 DE JUNHO 2026

A Pen created on CodePen.

Original URL: [https://codepen.io/Gabriel-Darienzo-Alves/pen/LEbdEoK](https://codepen.io/Gabriel-Darienzo-Alves/pen/LEbdEoK).

