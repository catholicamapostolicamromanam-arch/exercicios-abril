# Atividade de Front-End  - 05/05/2026

A Pen created on CodePen.

Original URL: [https://codepen.io/Gabriel-Darienzo-Alves/pen/WboQQBa](https://codepen.io/Gabriel-Darienzo-Alves/pen/WboQQBa).

